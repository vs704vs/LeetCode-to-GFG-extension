// background.js
// This file is intentionally left empty for now.
// You can add background tasks or message listeners here if needed in the future.

console.log("Background script loaded.");